create
    definer = root@localhost procedure Proc_Get_All_Employees()
BEGIN
    SELECT * FROM Employee WHERE is_deleted = 0;
END;

