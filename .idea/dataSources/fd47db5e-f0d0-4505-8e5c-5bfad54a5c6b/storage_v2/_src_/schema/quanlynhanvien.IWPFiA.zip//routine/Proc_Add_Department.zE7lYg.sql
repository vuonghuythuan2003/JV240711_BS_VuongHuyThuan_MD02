create
    definer = root@localhost procedure Proc_Add_Department(IN p_departmentId varchar(50),
                                                           IN p_departmentName varchar(255), IN p_description text)
BEGIN
    INSERT INTO Department (department_id, department_name, description, is_deleted)
    VALUES (p_departmentId, p_departmentName, p_description, FALSE);
END;

