create
    definer = root@localhost procedure Proc_Update_Employee(IN p_employee_id int, IN p_first_name varchar(50),
                                                            IN p_last_name varchar(50), IN p_date_of_birth date,
                                                            IN p_phone varchar(20), IN p_address varchar(255),
                                                            IN p_salary double, IN p_department_id varchar(50))
BEGIN
    UPDATE Employee
    SET first_name = p_first_name,
        last_name = p_last_name,
        date_of_birth = p_date_of_birth,
        phone = p_phone,
        address = p_address,
        salary = p_salary,
        department_id = p_department_id,
        update_at = NOW()
    WHERE employee_id = p_employee_id AND is_deleted = 0;
END;

