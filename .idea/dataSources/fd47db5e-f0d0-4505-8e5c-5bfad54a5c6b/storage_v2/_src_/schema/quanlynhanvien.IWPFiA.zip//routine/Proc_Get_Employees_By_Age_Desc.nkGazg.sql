create
    definer = root@localhost procedure Proc_Get_Employees_By_Age_Desc()
BEGIN
    SELECT *, TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) AS age
    FROM Employee
    WHERE is_deleted = 0
    ORDER BY age DESC;
END;

