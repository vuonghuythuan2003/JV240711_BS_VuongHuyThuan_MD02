create
    definer = root@localhost procedure Proc_Add_Employee(IN p_first_name varchar(50), IN p_last_name varchar(50),
                                                         IN p_date_of_birth date, IN p_phone varchar(20),
                                                         IN p_address varchar(255), IN p_salary double,
                                                         IN p_department_id varchar(50))
BEGIN
    INSERT INTO Employee (first_name, last_name, date_of_birth, phone, address, salary, department_id, created_at, is_deleted)
    VALUES (p_first_name, p_last_name, p_date_of_birth, p_phone, p_address, p_salary, p_department_id, NOW(), FALSE);
END;

