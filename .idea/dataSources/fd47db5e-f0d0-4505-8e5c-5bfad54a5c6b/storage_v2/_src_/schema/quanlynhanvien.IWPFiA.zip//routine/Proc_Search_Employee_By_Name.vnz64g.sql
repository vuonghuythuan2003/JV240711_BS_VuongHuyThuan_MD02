create
    definer = root@localhost procedure Proc_Search_Employee_By_Name(IN p_keyword varchar(100))
BEGIN
    SELECT * FROM Employee
    WHERE (first_name LIKE CONCAT('%', p_keyword, '%')
        OR last_name LIKE CONCAT('%', p_keyword, '%'))
      AND is_deleted = 0;
END;

