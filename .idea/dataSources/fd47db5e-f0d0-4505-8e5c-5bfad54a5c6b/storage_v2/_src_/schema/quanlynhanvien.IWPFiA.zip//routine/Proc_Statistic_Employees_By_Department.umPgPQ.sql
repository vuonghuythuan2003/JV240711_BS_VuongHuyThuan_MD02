create
    definer = root@localhost procedure Proc_Statistic_Employees_By_Department(IN dep_id varchar(5), OUT employee_count int)
BEGIN
    SELECT COUNT(*) INTO employee_count FROM Employee WHERE department_id = dep_id AND is_deleted = 0;
END;

