create
    definer = root@localhost procedure Proc_Delete_Employee(IN p_employee_id int)
BEGIN
    UPDATE Employee
    SET is_deleted = 1
    WHERE employee_id = p_employee_id;
END;

