create
    definer = root@localhost procedure Proc_Statistic_Employee_By_Age_Group()
BEGIN
    SELECT
        SUM(CASE WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN 18 AND 29 THEN 1 ELSE 0 END) AS age_18_29,
        SUM(CASE WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN 30 AND 49 THEN 1 ELSE 0 END) AS age_30_49,
        SUM(CASE WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) >= 50 THEN 1 ELSE 0 END) AS age_50_plus
    FROM Employee
    WHERE is_deleted = 0;
END;

