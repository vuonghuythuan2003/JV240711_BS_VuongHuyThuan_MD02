create
    definer = root@localhost procedure Proc_Update_Department(IN p_departmentId varchar(50),
                                                              IN p_departmentName varchar(100), IN p_description text)
BEGIN
    UPDATE Department
        SET department_name = p_departmentName,
            description = p_description
            WHERE department_id = p_departmentId AND is_deleted = 0;
end;

