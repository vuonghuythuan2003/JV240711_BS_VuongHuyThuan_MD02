create
    definer = root@localhost procedure Proc_Delete_Department(IN p_department_id varchar(50))
BEGIN
    UPDATE Department
    SET is_deleted = 1
    WHERE department_id = p_department_id;
END;

