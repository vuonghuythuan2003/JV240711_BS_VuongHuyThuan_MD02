create
    definer = root@localhost procedure Proc_Get_All_Departments()
BEGIN
    SELECT * FROM Department WHERE is_deleted = 0;
END;

